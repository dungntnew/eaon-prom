console.log('example 1 running...');
alert('example 1 js running');
